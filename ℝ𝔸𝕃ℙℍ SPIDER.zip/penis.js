let msg = {
viewOnceMessage: {
message: {
interactiveMessage: {
"contextInfo": {
"mentionedJid": [m.sender],
"isForwarded": true,
"forwardedNewsletterMessageInfo": {
"newsletterJid": '0@newsletter',
"newsletterName": 'By 𝗭𝗘𝗥𝗢 𝗘𝗫𝗘𝗖𝗨𝗧𝗜𝗢𝗡 𝗩𝗔𝗨𝗟𝗧',
"serverMessageId": 1
},
},
"header": {
"title": ``,
...(await prepareWAMessageMedia({ image: mengkece }, { upload: ryozingod.waUploadToServer })),
"hasMediaAttachment": true
},
"body": {
"text": ""
},
"footer": {
"text": "⿻  ⌜ 𝗭𝗘𝗥𝗢 𝗘𝗫𝗘𝗖𝗨𝗧𝗜𝗢𝗡 𝗩𝗔𝗨𝗟𝗧 ⌟  ⿻"
},
"nativeFlowMessage": {
"buttons": [
{
"name": "quick_reply",
"buttonParamsJson": "{\"display_text\":\"⿻𝐙͢𝐱𝐕⿻\nHOW FAR MY BRO, GUT OR WHATWVER😋😘\",\"id\":\".terkentod\"}"
}
],
"messageParamsJson": ""
}
}
}
}
}

ryozingod.relayMessage(m.chat, msg, {});

> let target = m.chat

async function pnis() {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
interactiveMessage: {
"contextInfo": {
"mentionedJid": [m.sender],
"isForwarded": true,
"forwardedNewsletterMessageInfo": {
"newsletterJid": '0@newsletter',
"newsletterName": 'By 𝗭𝗘𝗥𝗢 𝗘𝗫𝗘𝗖𝗨𝗧𝗜𝗢𝗡 𝗩𝗔𝗨𝗟𝗧',
"serverMessageId": 1
},
},
"header": {
"title": ``,
...(await prepareWAMessageMedia({ image: mengkece }, { upload: ryozingod.waUploadToServer })),
"hasMediaAttachment": true
},
"body": {
"text": ""
},
"footer": {
"text": "⿻  ⌜ 𝙕𝙀𝙍𝙊 𝙀𝙓𝙀𝘾𝙐𝙏𝙄𝙊𝙉 𝙑𝘼𝙐𝙇𝙏 ⌟  ⿻"
},
"nativeFlowMessage": {
"buttons": [
{
"name": "quick_reply",
"buttonParamsJson": "{\"display_text\":\"⿻𝐙͢𝐱𝐕⿻\n𝕭𝖗𝖚𝖛 𝕻𝖊𝖓𝖓𝖓𝖎𝖘𝖘𝖊𝖘 𝖕𝖊𝖓𝖓𝖎𝖘𝖎𝖓𝖌😋😘\",\"id\":\".terkentod\"}"
}
],
"messageParamsJson": ""
}
}
}
}
}), { userJid: target, quoted: m })
await ryozingod.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

pnis()